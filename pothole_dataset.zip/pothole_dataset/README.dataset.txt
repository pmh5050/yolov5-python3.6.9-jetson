# pothole > 2023-08-23 12:23am
https://universe.roboflow.com/hanyang-university-fpote/pothole-k2r46

Provided by a Roboflow user
License: CC BY 4.0

